clc;    
filename = 'C:\Users\Mike\Dropbox\CEE 536\Homework\Homework 13\TDfun.xlsx';
    A = xlsread(filename);
    
    x = A(2,1)