Readme

The word document of the portfolio was provided in addition to the pdf 
so that the reader may view the embedded videos.

Enjoy,
Mike